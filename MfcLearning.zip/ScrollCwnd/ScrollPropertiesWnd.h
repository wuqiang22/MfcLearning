#pragma once
#include "afxwin.h"
class ScrollPropertiesWnd :public CWnd
{
public:
	ScrollPropertiesWnd();
	~ScrollPropertiesWnd();

protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnPaint();

	DECLARE_MESSAGE_MAP()
};

