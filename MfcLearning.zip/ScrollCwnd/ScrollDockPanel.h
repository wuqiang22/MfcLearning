#pragma once

#include "ScrollPropertiesWnd.h"

class ScrollDockPanel : public CDockablePane
{
public:
	ScrollDockPanel();
	~ScrollDockPanel();

	void AdjustLayout();
protected:
	
	ScrollPropertiesWnd m_propertiesWnd;
protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);

	DECLARE_MESSAGE_MAP()
};

