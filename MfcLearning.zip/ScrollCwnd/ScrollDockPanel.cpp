#include "stdafx.h"
#include "ScrollDockPanel.h"
#include "Resource.h"


ScrollDockPanel::ScrollDockPanel()
{
}


ScrollDockPanel::~ScrollDockPanel()
{
}


BEGIN_MESSAGE_MAP(ScrollDockPanel, CDockablePane)
	ON_WM_CREATE()
	ON_WM_SIZE()
END_MESSAGE_MAP()


int ScrollDockPanel::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CDockablePane::OnCreate(lpCreateStruct) == -1)
		return -1;

	CRect rectDummy;
	rectDummy.SetRectEmpty();

	if (m_propertiesWnd.Create(AfxRegisterWndClass(0), _T("Properties View"), WS_CHILD | WS_VISIBLE | WS_BORDER, rectDummy, this, ID_SCROLL_PROPERTIES_VIEW) == -1)
	{
		return -1;
	}
	AdjustLayout();
	return 0;
}

void ScrollDockPanel::OnSize(UINT nType, int cx, int cy)
{
	CDockablePane::OnSize(nType, cx, cy);
	AdjustLayout();
}

void ScrollDockPanel::AdjustLayout()
{
	if (GetSafeHwnd() == NULL)
	{
		return;
	}

	CRect clientRect;
	GetClientRect(clientRect);
	int width = clientRect.Width();
	int height = clientRect.Height();
	m_propertiesWnd:SetWindowPos(NULL, clientRect.left, clientRect.top, 200, clientRect.Height(), SWP_NOACTIVATE | SWP_NOZORDER);
}