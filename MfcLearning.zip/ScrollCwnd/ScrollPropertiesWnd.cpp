#include "stdafx.h"
#include "ScrollPropertiesWnd.h"


BEGIN_MESSAGE_MAP(ScrollPropertiesWnd, CWnd)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_PAINT()
END_MESSAGE_MAP()


ScrollPropertiesWnd::ScrollPropertiesWnd()
{
}


ScrollPropertiesWnd::~ScrollPropertiesWnd()
{
}

int ScrollPropertiesWnd::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
	{
		return -1;
	}
	return 0;
}

void ScrollPropertiesWnd::OnSize(UINT nType, int cx, int cy)
{
	CWnd::OnSize(nType, cx, cy);
}

void ScrollPropertiesWnd::OnPaint()
{

}